function ds = double2single(ds)
% ds = data structure


fnames = fieldnames(ds);
for f=1:length(fnames)
    if eval(sprintf('isa(ds.%s,''double'')',fnames{f}))
        eval(sprintf('ds.%s = single(ds.%s);',fnames{f},fnames{f}))
    end
end

 
