function set_source_cfg(varargin)
global h
