function menu_filt_type_Callback(varargin)
global h
