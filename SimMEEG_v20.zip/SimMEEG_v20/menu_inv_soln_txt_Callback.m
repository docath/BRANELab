function menu_inv_soln_txt_Callback(varargin)
global h
if h.menu_inv_soln.Value<=3     % BRANE Lab's beamformers
    h.panel_SPA_params.Visible = 'on';
    h.panel_SPA_params.Title = sprintf('%s Parameters', h.menu_inv_soln.String{h.menu_inv_soln.Value});
    if h.menu_inv_soln.Value>1 % SIA/MIA
        h.menu_SPA_loc_flag.String = {'MPZ','MER','RMER','MAI'};
        h.edit_SPA_max_sources_txt.Visible = 'on'; h.edit_SPA_max_sources.Visible = 'on';
    else
       h.menu_SPA_loc_flag.String = {'pseudo Z','event-related','reduced event-related','activity index'};
        h.edit_SPA_max_sources_txt.Visible = 'off'; h.edit_SPA_max_sources.Visible = 'off';
    end
    
elseif h.menu_inv_soln.Value>3  &&   h.menu_inv_soln.Value<=7 % Field Trip's Inv Soln
    h.panel_SPA_params.Visible = 'off';
elseif h.menu_inv_soln.Value>=8  &&   h.menu_inv_soln.Value<=9   % Alex Moiseev's sub-space MCMV beamformer and bRAPBeam
    h.panel_SPA_params.Visible = 'on'; 
    h.panel_SPA_params.Title = sprintf('%s Parameters', h.menu_inv_soln.String{h.menu_inv_soln.Value});
    h.menu_SPA_loc_flag.String = {'MPZ','MER','RMER','MAI'}; 
    if h.menu_inv_soln.Value>1 % SIA/MIA
        h.edit_SPA_max_sources_txt.Visible = 'on'; h.edit_SPA_max_sources.Visible = 'on';
    else
        h.edit_SPA_max_sources_txt.Visible = 'off'; h.edit_SPA_max_sources.Visible = 'off';
    end
else
    h.panel_SPA_params.Visible = 'off';
end
