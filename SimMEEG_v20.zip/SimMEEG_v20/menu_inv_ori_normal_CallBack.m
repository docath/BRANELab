function menu_inv_ori_normal_CallBack(varargin)
global h

