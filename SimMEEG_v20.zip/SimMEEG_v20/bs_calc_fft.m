function bs_calc_fft(varargin)
global h

ln_clr = lines(length(h.current_3D_peak_idx)); ln_clr(1:3,:) = h.src_clr;

h.axes_source_fft.NextPlot='replace';
for v=1:length(h.current_3D_peak_idx)
data = h.current_peak_swf(:,v);

L=length(data);
nfft = 2^nextpow2(L);
fft_data=fft(data,nfft)/L;
freqs=h.sim_data.cfg.study.srate/2*linspace(0,1,nfft/2+1);


plot(h.axes_source_fft,freqs,2*abs(fft_data(1:nfft/2+1,:)),'color',ln_clr(v,:),'linewidth',2);
% plot(h.axes_source_fft,freqs,unwrap(angle(fft_data(1:nfft/2+1,:))),'color',v_vlr(v,:),'linewidth',2);   xlabel('Frequency (Hz)'); ylabel('Phase');
h.axes_source_fft.XLabel.String= 'Frequency (Hz)'; h.axes_source_fft.YLabel.String= 'Amplitude |y(f)|';
h.axes_source_fft.NextPlot='add';


end
box on; axis on; 
h.axes_source_fft.XLim = str2num(h.edit_plot_freq_int.String);
h.axes_source_fft.Title.String='FFT';
