function set_3D_transparency(varargin)
global h

switch h.inv_soln(h.current_inv_soln).headmodel_type
    case 'Whole Brain' % whole brain
        xh=handle(h.func3D);
        for a=1:length(xh); xh(a).FaceAlpha = h.slider_3D_transparency_func.Value; end
        h.anat3D.FaceAlpha = h.slider_3D_transparency_anat.Value;
    case 'Cortical Surface'    % Cortical Surface
        h.func3D(1).FaceAlpha = h.slider_3D_transparency_anat.Value;
        h.func3D(2).FaceAlpha = h.slider_3D_transparency_func.Value; 
end
