function run_source_modeling(varargin)
%% Run Source modeling
global h

% Do NOT re-reference - it messes up the inverse solution
% if h.menu_sens_type.Value==1    % MEG
%     ref_idx = h.anatomy.meg_chans;
% elseif h.menu_sens_type.Value==2    % EEG
%     ref_idx = h.anatomy.good_chans;
% end
% xdata = bl_reref (permute(h.sim_data.sens_final,[2 1 3]),ref_idx,[]);
% h.sim_data.sens_final = permute(xdata,[2 1 3]);
try
h.next_inv_soln = length(h.inv_soln)+1;
h.current_inv_soln = h.next_inv_soln;
inv_soln = h.menu_inv_soln.String{h.menu_inv_soln.Value};
% fprintf('Inverse Modeling using %s\n',inv_soln);
% hm = msgbox(sprintf('Running Inverse Source Modeling\n\n          %s',inv_soln));
h.waitfor_panel.Visible='off'; h.waitfor_txt.String = sprintf('Inverse Modeling using %s\n',inv_soln); drawnow;

%% make-shift paramaters right now to test simulations
if h.menu_inv_headmodel.Value==1    % Whole Brain
    if h.menu_sens_type.Value == 1 %MEG
        h.inv_soln(h.next_inv_soln).leadfield =  h.anatomy.leadfield_meg_vol;
        h.inv_soln(h.next_inv_soln).headmodel =  h.anatomy.headmodel_meg;
        h.inv_soln(h.next_inv_soln).sens =  h.anatomy.sens_meg;
        h.inv_soln(h.current_inv_soln).headmodel_type = 'Whole Brain';
    elseif h.menu_sens_type.Value == 2 %EEG
        h.inv_soln(h.next_inv_soln).leadfield =  h.anatomy.leadfield_eeg_vol;
        h.inv_soln(h.next_inv_soln).headmodel =  h.anatomy.headmodel_eeg;
        h.inv_soln(h.next_inv_soln).sens =  h.anatomy.sens_eeg;
        h.inv_soln(h.current_inv_soln).headmodel_type = 'Whole Brain';
    end
    h.inv_soln(h.next_inv_soln).headmodel_mesh =  h.anatomy.mesh_volumes(3);
    
elseif h.menu_inv_headmodel.Value==2    % Cortical Surface
    if h.menu_sens_type.Value == 1 %MEG
        h.inv_soln(h.next_inv_soln).leadfield =  h.anatomy.leadfield_meg_cortex;
        h.inv_soln(h.next_inv_soln).headmodel =  h.anatomy.headmodel_meg;
        h.inv_soln(h.next_inv_soln).sens =  h.anatomy.sens_meg;
        h.inv_soln(h.current_inv_soln).headmodel_type = 'Cortical Surface';
    elseif h.menu_sens_type.Value == 2 %EEG
        
        h.inv_soln(h.next_inv_soln).leadfield =  h.anatomy.leadfield_eeg_cortex;
        h.inv_soln(h.next_inv_soln).headmodel =  h.anatomy.headmodel_eeg;
        h.inv_soln(h.next_inv_soln).sens =  h.anatomy.sens_eeg;
        h.inv_soln(h.current_inv_soln).headmodel_type = 'Cortical Surface';
    end
    h.inv_soln(h.next_inv_soln).headmodel_mesh =  h.anatomy.mesh_volumes(5);
    
end

inside_idx = find(h.inv_soln(h.current_inv_soln).leadfield.inside==1);
h.cfg.study.bl_bmf.inside_idx = inside_idx;
data = h.sim_data.sens_final; % [samples x channels x trials]
mHref = []; mref = [];

%% Preprocesing Data for Field Trip
if h.menu_inv_soln.Value>3
    
    %% convert BrainSim data to Field Trip data format
    ft_data = convert_bs2ft_data(data,h.anatomy,h.cfg);
    h.ft_data = ft_data;
    
    %% using same noise covariance for all inverse solns;
    soln=[];
    soln.lambda    = .05;       % 1e-9 is good for phase-coupling for MNE according to [Ana-Sof�a Hincapi�a et al., 2017 Neuroimage 156: 29-42; Ana-Sof�a Hincapi�a  et al., Computational Intelligence and Neuroscience Volume 2016, Article ID 3979547, 11 pages] = scalar value, regularisation parameter for the noise covariance matrix (default = 0)
    % soln.lambdanoise    = 1e-9;
    soln.powmethod = 'lambda1'; %        = can be 'trace' or 'lambda1'
    soln.feedback = 'none'; %'         = give ft_progress indication, can be 'text', 'gui' or 'none' (default)
    soln.fixedori= 'yes'; %        = use fixed or free orientation,                   can be 'yes' or 'no'
    soln.projectnoise = 'yes'; %     = project noise estimate through filter,           can be 'yes' or 'no'
    soln.projectmom = 'yes'; %      = project the dipole moment timecourse on the direction of maximal power, can be 'yes' or 'no'
    soln.keepfilter = 'yes'; %      = remember the beamformer filter,                  can be 'yes' or 'no'
    soln.keepleadfield = 'yes'; %    = remember the forward computation,                can be 'yes' or 'no'
    soln.keepmom = 'no'; %          = remember the estimated dipole moment timeseries, can be 'yes' or 'no'
    soln.keepcov = 'no'; %          = remember the estimated dipole covariance,        can be 'yes' or 'no'
    soln.kurtosis = 'no'; %         = compute the kurtosis of the dipole timeseries,   can be 'yes' or 'no'
    % These options influence the forward computation of the leadfield
    soln.reducerank= 'no'; %      = reduce the leadfield rank, can be 'no' or a number (e.g. 2)
    soln.normalize= 'yes'; %        = normalize the leadfield
    soln.normalizeparam= 0.5; %  = parameter for depth normalization (default = 0.5)
    soln.prewhiten = 'yes';  % = 'no' or 'yes', prewhiten the leadfield matrix with the noise covariance matrix C
    % soln.realfilter   = 'yes';
    
end

%% getting Active & Control intervals
h.cfg.study.bl_bmf.act_int = str2num(h.edit_act_int.String); % active interval set by user
h.cfg.study.bl_bmf.ctrl_int = str2num(h.edit_ctrl_int.String);
act_s = round( (h.cfg.study.bl_bmf.act_int-h.cfg.study.lat_sim(1)) *h.cfg.study.srate);     act_s(act_s==0)=1;
ctrl_s = round( (h.cfg.study.bl_bmf.ctrl_int-h.cfg.study.lat_sim(1)) *h.cfg.study.srate);   ctrl_s(ctrl_s==0)=1;
h.cfg.study.bl_bmf.act_samps = act_s(1):act_s(end);
h.cfg.study.bl_bmf.ctrl_samps = ctrl_s(1):ctrl_s(end);
bs = round( (h.cfg.study.base_int-h.cfg.study.lat_sim(1))*h.cfg.study.srate);
h.cfg.study.h.cfg.study.base_samps = bs(1):bs(2); %           params.study.h.cfg.study.base_samps;     % -300 to 0 ms


h.cfg.study.bl_bmf.slice_orient = [1 1 1]; h.cfg.study.bl_bmf.sFaceAlpha = .25;
h.cfg.study.bl_bmf.vw_angle = [0 90];

h.inv_soln(h.current_inv_soln).params = h.cfg.study.bl_bmf;


%% Inv Modelling
switch inv_soln
    case 'SPA'
        %% SPA
        
        h.cfg.study.bl_bmf.loc_flag = h.menu_SPA_loc_flag.Value-1;
        h.cfg.study.bl_bmf.noise_alpha = str2num(h.edit_SPA_noise_alpha.String);
        [SPA]=BRANElab_LCMV_beamformer_SPA(h.inv_soln(h.next_inv_soln).leadfield.H,data,...
            h.cfg.study.bl_bmf.act_samps,h.cfg.study.bl_bmf.ctrl_samps,h.cfg.study.bl_bmf.loc_flag,h.cfg.study.bl_bmf.noise_alpha);
        h.inv_soln(h.next_inv_soln).Type = 'SPA';
        h.inv_soln(h.next_inv_soln).soln = SPA;
        
    case 'SIA'
        h.cfg.study.bl_bmf.loc_flag = h.menu_SPA_loc_flag.Value-1;
        h.cfg.study.bl_bmf.plot_flag=0; h.cfg.study.bl_bmf.text_flag=1;
        h.cfg.study.bl_bmf.perc_crit = 2;
        
        
        %% SIA
        [SIA]=BRANElab_MCMV_beamformer_SIA(h.inv_soln(h.next_inv_soln).leadfield.H,[],[],data,...
            h.cfg.study.bl_bmf.act_samps,h.cfg.study.bl_bmf.ctrl_samps,...
            h.inv_soln(h.next_inv_soln).leadfield.voxel_pos,h.cfg.study.bl_bmf.loc_flag,h.cfg.study.bl_bmf.plot_flag,h.cfg.study.bl_bmf.perc_crit,h.cfg.study.bl_bmf.noise_alpha);
        h.inv_soln(h.next_inv_soln).Type = 'SIA';
        h.inv_soln(h.next_inv_soln).soln = SIA;
        %         h.inv_soln(h.next_inv_soln).soln.P.img_org = h.inv_soln(h.next_inv_soln).soln.P.img;
        %         h.inv_soln(h.next_inv_soln).soln.P.img = h.inv_soln(h.next_inv_soln).soln.P.nulled_img; % shifting to nulled img
        %         h.inv_soln(h.next_inv_soln).soln.wts_org = h.inv_soln(h.next_inv_soln).soln.wts;
        %         h.inv_soln(h.next_inv_soln).soln.wts = h.inv_soln(h.next_inv_soln).soln.nulled_wts;
        
    case 'MIA'
        h.cfg.study.bl_bmf.loc_flag = h.menu_SPA_loc_flag.Value-1;
        h.cfg.study.bl_bmf.plot_flag=0; h.cfg.study.bl_bmf.text_flag=1;
        h.cfg.study.bl_bmf.perc_crit = 2;
        
        
        %% MIA
        [MIA]=BRANElab_MCMV_beamformer_MIA(h.inv_soln(h.next_inv_soln).leadfield.H,[],[],data,...
            h.cfg.study.bl_bmf.act_samps,h.cfg.study.bl_bmf.ctrl_samps,...
            h.inv_soln(h.next_inv_soln).leadfield.voxel_pos,h.cfg.study.bl_bmf.loc_flag,h.cfg.study.bl_bmf.plot_flag,h.cfg.study.bl_bmf.perc_crit,h.cfg.study.bl_bmf.noise_alpha,h.cfg.study.bl_bmf.text_flag,h.anatomy);
        h.inv_soln(h.next_inv_soln).Type = 'MIA';
        h.inv_soln(h.next_inv_soln).soln = MIA;
        %         h.inv_soln(h.next_inv_soln).soln.P.img_org = h.inv_soln(h.next_inv_soln).soln.P.img;
        %         h.inv_soln(h.next_inv_soln).soln.P.img = h.inv_soln(h.next_inv_soln).soln.P.nulled_img; % shifting to nulled img
        %         h.inv_soln(h.next_inv_soln).soln.wts_org = h.inv_soln(h.next_inv_soln).soln.wts;
        %         h.inv_soln(h.next_inv_soln).soln.wts = h.inv_soln(h.next_inv_soln).soln.nulled_wts;
        
    case 'LCMV'
        act_int = str2num(h.edit_act_int.String);
        ctrl_int = str2num(h.edit_ctrl_int.String);
        inside_idx = find(h.inv_soln(h.current_inv_soln).leadfield.inside==1);
        
        %% averaging data and getting covariance matrix
        cfg = []; cfg.baseline = h.sim_data.cfg.study.base_int;
        ft_data = ft_timelockbaseline(cfg, ft_data);
        cfg = [];
        cfg.covariance='yes';
        cfg.covariancewindow = [ctrl_int(1) act_int(2)]; % calculating covariance across entire ctrl and act interval just as stated in Field Trip's Tutorial
        avg_data = ft_timelockanalysis(cfg,ft_data);
        
        %% Calculating LCMV
        cfg = [];
        cfg.lcmv = soln;
        cfg.keepleadfield = cfg.lcmv.keepleadfield;
        cfg.reducerank = cfg.lcmv.reducerank;
        cfg.normalize = cfg.lcmv.normalize;
        cfg.normalizeparam = cfg.lcmv.normalizeparam;
        
        cfg.lcmv=rmfield(cfg.lcmv,'keepleadfield');  cfg.lcmv=rmfield(cfg.lcmv,'reducerank');
        cfg.lcmv=rmfield(cfg.lcmv,'normalize');  cfg.lcmv=rmfield(cfg.lcmv,'normalizeparam');
        
        cfg.method              = 'lcmv';
        cfg.lcmv.fixedori            = 'yes'; %  'yes' = get single orientation using svd
        cfg.weightnorm          = 'arraygain'; % ''; %'nai'; %'unitnoisegain'; %'unitgain'; %'arraygain'; % 'nai';  % based on equation 4.47 from Sekihara & Nagarajan (2008)
        cfg.grad                = h.inv_soln(h.next_inv_soln).sens;
        cfg.sourcemodel               = h.inv_soln(h.next_inv_soln).leadfield;
        cfg.headmodel           = h.inv_soln(h.next_inv_soln).headmodel;
        cfg.lcmv.lambda         = '5%';
        LCMV = ft_sourceanalysis(cfg, avg_data);
        
        %% creating LCMV power image and estimating orientations
        LCMV.P.img= LCMV.avg.pow(inside_idx)./LCMV.avg.noise(inside_idx);   % simple ratio
        %                 LCMV.P.img= (LCMV.avg.pow(inside_idx)-LCMV.avg.noise(inside_idx)) ./LCMV.avg.noise(inside_idx);   % deviation ratio ???
        %                 LCMV.P.img= (LCMV.avg.pow(inside_idx)-LCMV.avg.noise(inside_idx)) ./ (LCMV.avg.pow(inside_idx)+LCMV.avg.noise(inside_idx));   % deviation ratio ???
        
        nd=sort(LCMV.P.img); LCMV.null_thresh=nd(ceil(length(nd)*h.cfg.study.bl_bmf.noise_alpha)); %img(img<pthresh)=0;
        ori=cell2mat(LCMV.avg.ori(inside_idx)); LCMV.ori=ori';
        wts = cell2mat(LCMV.avg.filter(inside_idx)); LCMV.wts = wts';
        
        %                 img=LCMV.P.img; ori=LCMV.ori; null_thresh=max(img)*.55;
        %                 min_max=[min(img) max(img)*.95];  vol_types=1;
        %                 seed_idx = 1:3;  ln_wdth = 1; ln_wdth2 = 2;
        %                 figure(1004); clf; [peak_voxels,p_idx]=bl_plot_lcmv_peak_img_FT_new(img,ori,null_thresh,8,h.anatomy.leadfield.voxel_pos,jet(255),min_max,h.anatomy.vol.bnd(3),[],...
        %                     h.cfg.study.bl_bmf.vw_angle,1,vol_types,h.anatomy.leadfield.pos,inside_idx,h.cfg.study.bl_bmf.slice_orient,h.cfg.study.bl_bmf.sFaceAlpha);
        %                 hold on; mrk_size=150; s1=scatter3(h.cfg.source.vx_locs(seed_idx,1),h.cfg.source.vx_locs(seed_idx,2),h.cfg.source.vx_locs(seed_idx,3),'k+','sizedata',mrk_size,'linewidth',ln_wdth); s2=scatter3(h.cfg.source.vx_locs(seed_idx,1),h.cfg.source.vx_locs(seed_idx,2),h.cfg.source.vx_locs(seed_idx,3),'ks','sizedata',mrk_size,'linewidth',ln_wdth2);
        %                 title('FT LCMV'); colorbar; caxis(min_max);
        
        % removing 'avg' to reduce storage space
        LCMV = rmfield(LCMV,{'avg'}); %MNE.avg = rmfield(MNE.avg,{'mom','filter','noisecov'});

        h.inv_soln(h.next_inv_soln).Type = 'LCMV';
        h.inv_soln(h.next_inv_soln).soln = LCMV;
        
    case 'eLORETA'
        act_int = str2num(h.edit_act_int.String);
        ctrl_int = str2num(h.edit_ctrl_int.String);
        inside_idx = find(h.inv_soln(h.current_inv_soln).leadfield.inside==1);
        
        %% averaging data and getting covariance matrix
        cfg = []; cfg.baseline = h.sim_data.cfg.study.base_int;
        ft_data = ft_timelockbaseline(cfg, ft_data);
        cfg = [];
        cfg.covariance='yes';
        cfg.covariancewindow = [ctrl_int(1) act_int(2)]; % calculating covariance across entire ctrl and act interval just as stated in Field Trip's Tutorial
        avg_data = ft_timelockanalysis(cfg,ft_data);
        
        %% FT eLORETA
        cfg=[];
        cfg.method = 'eloreta';
        cfg.eloreta = soln; % using same additional options for all inverse solns
        cfg.eloreta.lambda = 1;
        cfg.keepleadfield = cfg.eloreta.keepleadfield;
        cfg.reducerank = cfg.eloreta.reducerank;
        cfg.normalize = cfg.eloreta.normalize;
        cfg.normalizeparam = cfg.eloreta.normalizeparam;
        cfg.eloreta=rmfield(cfg.eloreta,'keepleadfield');  cfg.eloreta=rmfield(cfg.eloreta,'reducerank');  
        cfg.eloreta=rmfield(cfg.eloreta,'normalize');  cfg.eloreta=rmfield(cfg.eloreta,'normalizeparam');  

        cfg.grad                = h.inv_soln(h.next_inv_soln).sens;
        cfg.sourcemodel               = h.inv_soln(h.next_inv_soln).leadfield;
        cfg.headmodel           = h.inv_soln(h.next_inv_soln).headmodel;
        eloreta  = ft_sourceanalysis(cfg,avg_data);
        
        %% calculating image power from filter weights;
        base_samps=h.sim_data.cfg.study.base_samps;     % -300 to 0 ms
        act_samps=h.cfg.study.bl_bmf.act_samps;
        ctrl_samps=h.cfg.study.bl_bmf.ctrl_samps;
        ctrl_samps1 = ctrl_samps(1:round(length(ctrl_samps)/2));
        ctrl_samps2 = ctrl_samps(round(length(ctrl_samps)/2)+1:end);
        
        y=cell2mat(eloreta.avg.filter); eloreta.wts=permute(reshape(y,[size(y,1) size(y,2)/length(inside_idx) length(inside_idx)]),[3 1 2]);
%         for ox = 1:size(eloreta.wts,2)
%             eloreta.swf(:,ox,:)=avg_data.avg'*squeeze(eloreta.wts(:,ox,:))';
%         end
        %         eloreta.wts = y';
        eloreta.wts = permute(eloreta.wts,[3 1 2]);

        eloreta.P.img = squeeze(eloreta.avg.pow(inside_idx));  % source image based on recalcuated swf data
        ori = cell2mat(eloreta.avg.ori(inside_idx));
        eloreta.ori = ori';
        
        eloreta = rmfield(eloreta,{'avg'}); %MNE.avg = rmfield(MNE.avg,{'mom','filter','noisecov'});

        h.inv_soln(h.next_inv_soln).Type = 'eLORETA';
        h.inv_soln(h.next_inv_soln).soln = eloreta;
        
        %                 %% PLotting eLORETA on new figure
        %                     img=eloreta.P.img; ori=eloreta.ori; null_thresh=max(img)*.15;
        %                 min_max=[min(img) max(img)*.85]; %min_max = [0 5];
        %                 sFaceAlpha=0; vol_types=1;
        %                 figure(1006); clf; [peak_voxels,p_idx]=bl_plot_lcmv_peak_img_FT_new(img,ori,null_thresh,15,h.anatomy.leadfield.voxel_pos,jet(255),min_max,h.anatomy.vol.bnd(3),[],...
        %                     h.cfg.study.bl_bmf.vw_angle,1,vol_types,h.anatomy.leadfield.pos,h.cfg.study.bl_bmf.inside_idx,h.cfg.study.bl_bmf.slice_orient,h.cfg.study.bl_bmf.sFaceAlpha);
        %                 seed_idx = 1:3;  ln_wdth = 1; ln_wdth2 = 2;
        %                 hold on; mrk_size=150; s1=scatter3(h.cfg.source.vx_locs(seed_idx,1),h.cfg.source.vx_locs(seed_idx,2),h.cfg.source.vx_locs(seed_idx,3),'k+','sizedata',mrk_size,'linewidth',ln_wdth); s2=scatter3(h.cfg.source.vx_locs(seed_idx,1),h.cfg.source.vx_locs(seed_idx,2),h.cfg.source.vx_locs(seed_idx,3),'ks','sizedata',mrk_size,'linewidth',ln_wdth2);
        %
        %                 title('FT eLORETA'); colorbar; caxis(map_scale);
        
    case 'sLORETA'
        act_int = str2num(h.edit_act_int.String);
        ctrl_int = str2num(h.edit_ctrl_int.String);
        inside_idx = find(h.inv_soln(h.current_inv_soln).leadfield.inside==1);
        
        %% averaging data and getting covariance matrix
        cfg = []; cfg.baseline = h.sim_data.cfg.study.base_int;
        ft_data = ft_timelockbaseline(cfg, ft_data);
        cfg = [];
        cfg.covariance='yes';
        cfg.covariancewindow = [ctrl_int(1) act_int(2)]; % calculating covariance across entire ctrl and act interval just as stated in Field Trip's Tutorial
        avg_data = ft_timelockanalysis(cfg,ft_data);
        
        %% FT sLORETA
        cfg=[];
        cfg.method = 'sloreta';
        cfg.sloreta = soln; % using same additional options for all inverse solns
        cfg.sloreta.lambda =  '5%';
        cfg.keepleadfield = cfg.sloreta.keepleadfield;
        cfg.reducerank = cfg.sloreta.reducerank;
        cfg.normalize = cfg.sloreta.normalize;
        cfg.normalizeparam = cfg.sloreta.normalizeparam;

        cfg.sloreta=rmfield(cfg.sloreta,'keepleadfield');  cfg.sloreta=rmfield(cfg.sloreta,'reducerank');  
        cfg.sloreta=rmfield(cfg.sloreta,'normalize');  cfg.sloreta=rmfield(cfg.sloreta,'normalizeparam');  
        
        cfg.grad                = h.inv_soln(h.next_inv_soln).sens;
        cfg.sourcemodel               = h.inv_soln(h.next_inv_soln).leadfield;
        cfg.headmodel           = h.inv_soln(h.next_inv_soln).headmodel;
        sloreta  = ft_sourceanalysis(cfg,avg_data);
        
        %% calculating image power from filter weights;
        base_samps=h.sim_data.cfg.study.base_samps;     % -300 to 0 ms
        act_samps=h.cfg.study.bl_bmf.act_samps;
        ctrl_samps=h.cfg.study.bl_bmf.ctrl_samps;
        ctrl_samps1 = ctrl_samps(1:round(length(ctrl_samps)/2));
        ctrl_samps2 = ctrl_samps(round(length(ctrl_samps)/2)+1:end);
        
        y=cell2mat(sloreta.avg.filter); %sloreta.wts=permute(reshape(y,[3 size(y,2)/length(inside_idx) length(inside_idx)]),[3 1 2]);
        sloreta.wts = y';
%         sloreta.wts = permute(sloreta.wts,[3 1 2]);

%                 sloreta.P.img=squeeze(sloreta.avg.pow(inside_idx));  % source image based on recalcuated swf data
        sloreta.P.img=squeeze(sloreta.avg.pow(inside_idx)./sloreta.avg.noise(inside_idx));  % source image based on recalculated swf data
        ori = cell2mat(sloreta.avg.ori(inside_idx));
        sloreta.ori = ori';
        
        sloreta = rmfield(sloreta,{'avg'}); %MNE.avg = rmfield(MNE.avg,{'mom','filter','noisecov'});

        h.inv_soln(h.next_inv_soln).Type = 'sLORETA';
        h.inv_soln(h.next_inv_soln).soln = sloreta;
        
        %         %% PLotting sloreta on new figure
        %             img=sloreta.P.img; ori=sloreta.ori; null_thresh=sloreta.null_thresh*2;
        %         min_max=[min(img) max(img)*.15]; %min_max = [0 5];
        %         sFaceAlpha=0; vol_types=1;
        %         figure(1006); clf; [peak_voxels,p_idx]=bl_plot_lcmv_peak_img_FT_new(img,ori,null_thresh,15,h.anatomy.leadfield.voxel_pos,jet(255),min_max,h.anatomy.vol.bnd(3),[],...
        %             h.cfg.study.bl_bmf.vw_angle,1,vol_types,h.anatomy.leadfield.pos,h.cfg.study.bl_bmf.inside_idx,h.cfg.study.bl_bmf.slice_orient,h.cfg.study.bl_bmf.sFaceAlpha);
        %         seed_idx = 1:3;  ln_wdth = 1; ln_wdth2 = 2;
        %         hold on; mrk_size=150; s1=scatter3(h.cfg.source.vx_locs(seed_idx,1),h.cfg.source.vx_locs(seed_idx,2),h.cfg.source.vx_locs(seed_idx,3),'k+','sizedata',mrk_size,'linewidth',ln_wdth); s2=scatter3(h.cfg.source.vx_locs(seed_idx,1),h.cfg.source.vx_locs(seed_idx,2),h.cfg.source.vx_locs(seed_idx,3),'ks','sizedata',mrk_size,'linewidth',ln_wdth2);
        %
        %         title('FT sLORETA'); colorbar; caxis(map_scale);
        
        
    case 'MNE'
        act_int = str2num(h.edit_act_int.String);
        ctrl_int = str2num(h.edit_ctrl_int.String);
        inside_idx = find(h.inv_soln(h.current_inv_soln).leadfield.inside==1);
        
        %% averaging data and getting covariance matrix
        cfg = []; cfg.baseline = h.sim_data.cfg.study.base_int;
        ft_data = ft_timelockbaseline(cfg, ft_data);
        cfg = [];
        cfg.covariance='yes';
        %         cfg.covariancewindow = [ctrl_int(1) act_int(2)]; % calculating covariance across entire ctrl and act interval just as stated in Field Trip's Tutorial
        cfg.covariancewindow = [-inf 0];
        avg_data = ft_timelockanalysis(cfg,ft_data);
        
        %% FT MNE
        cfg = [];
        cfg.mne = soln;
        cfg.keepleadfield = cfg.mne.keepleadfield;
        cfg.reducerank = cfg.mne.reducerank;
        cfg.normalize = cfg.mne.normalize;
        cfg.normalizeparam = cfg.mne.normalizeparam;
        
        cfg.mne=rmfield(cfg.mne,'keepleadfield');  cfg.mne=rmfield(cfg.mne,'reducerank');  
        cfg.mne=rmfield(cfg.mne,'normalize');  cfg.mne=rmfield(cfg.mne,'normalizeparam');  

        cfg.method              = 'mne';
        cfg.mne.fixedori            = 'yes'; %  'yes' = get single orientation using svd
        cfg.weightnorm          = 'nai';  % based on equation 4.47 from Sekihara & Nagarajan (2008)
        cfg.grad                = h.inv_soln(h.next_inv_soln).sens;
        cfg.sourcemodel               = h.inv_soln(h.next_inv_soln).leadfield;
        cfg.headmodel           = h.inv_soln(h.next_inv_soln).headmodel;
        cfg.mne.prewhiten = 'yes';
        cfg.mne.lambda    = 3;
        cfg.mne.scalesourcecov = 'yes';
        %         cfg.mne.cov=soln.cov; %params.ctrl_cov; % must use noise covariance for MNE to return reasonable results based on simulated data
        %         avg_data.cov=soln.cov; %params.ctrl_cov;
        
        %             cfg.mne.powmethod = 'trace'; %        = can be 'trace' or 'lambda1'
        %              cfg.mne.lambda    = 1e-9;       % 1e-9 is good for phase-coupling for MNE according to [Ana-Sof�a Hincapi�a et al., 2017 Neuroimage 156: 29-42; Ana-Sof�a Hincapi�a  et al., Computational Intelligence and Neuroscience Volume 2016, Article ID 3979547, 11 pages] = scalar value, regularisation parameter for the noise covariance matrix (default = 0)
        %                 cfg.mne.lambda    = 1e-7;       % 1e-9 is good for power localization for MNE according to [Ana-Sof�a Hincapi�a et al., 2017 Neuroimage 156: 29-42; Ana-Sof�a Hincapi�a  et al., Computational Intelligence and Neuroscience Volume 2016, Article ID 3979547, 11 pages] = scalar value, regularisation parameter for the noise covariance matrix (default = 0)
        %              cfg.mne.scalesourcecov = 'yes';
        MNE = ft_sourceanalysis(cfg,avg_data);
        
        
        % calculating image power from filter weights;
        y=cell2mat(permute(MNE.avg.filter,[2 1])); MNE.wts=permute(reshape(y,[3 size(y,1)/3 size(y,2)]),[2 1 3]);
        MNE.swf=[];MNE.swf_snr=[];MNE.swf_pwr=[];MNE.noise_pwr=[];
        for ox=1:3
            MNE.swf(:,ox,:)=avg_data.avg'*squeeze(MNE.wts(:,ox,:))';
            %    swf_snr(:,ox,:)=20*log10(bsxfun(@rdivide,swf(:,ox,:),nanmean(swf(h.cfg.study.base_samps,ox,:),1)));
            %   MNE.swf_snr(:,ox,:)=(bsxfun(@rdivide,MNE.swf(:,ox,:),nanmean(MNE.swf(h.cfg.study.base_samps,ox,:),1))); % SNR in percent from baseline
            %            MNE.swf_snr(:,ox,:)=(bsxfun(@rdivide,MNE.swf(:,ox,:),nanstd(MNE.swf(h.cfg.study.base_samps,ox,:),1))); % normalized to baseline
            MNE.swf_pwr(ox,:)=rms(MNE.swf(h.cfg.study.bl_bmf.act_samps,ox,:),1)./rms(MNE.swf(h.cfg.study.bl_bmf.ctrl_samps,ox,:),1);
            %            MNE.noise_pwr(ox,:)=rms(MNE.swf(h.cfg.study.bl_bmf.ctrl_samps,ox,:),1)./rms(MNE.swf(h.cfg.study.bl_bmf.ctrl_samps,ox,:),1);
        end
        MNE.wts = permute(MNE.wts,[3 1 2]);
        MNE.P.img = abs(squeeze(nanmean(rms(MNE.swf(h.cfg.study.bl_bmf.act_samps,:,:),2))));
        %        MNE.P.img = MNE.avg.pow(inside_idx,s);
        %        MNE.P.img = abs(squeeze(rms(MNE.swf(s,:,:),2)));
        
        %        MNE.P.img=squeeze(max(abs(MNE.avg.pow(h.cfg.study.bl_bmf.inside_idx,h.cfg.study.bl_bmf.act_samps))'))';
        %    MNE.P.img=squeeze(max(max(MNE.swf_snr(h.cfg.study.bl_bmf.act_samps,:,:))));
        %    MNE.P.img=squeeze(rms(MNE.swf_pwr,1))';   % averaging across orientations
        %    MNE.P.img=squeeze(rms(MNE.swf_pwr./MNE.noise_pwr,1))';   % averaging across orientations
        nd=sort(MNE.P.img); MNE.null_thresh=nd(ceil(length(nd)*h.cfg.study.bl_bmf.noise_alpha)); %img(img<pthresh)=0;
        % Approximating orientations for plotting purposes only.
        x=MNE.swf_pwr(1,:)./max(MNE.swf_pwr,[],1);
        y=MNE.swf_pwr(2,:)./max(MNE.swf_pwr,[],1);
        z=MNE.swf_pwr(3,:)./max(MNE.swf_pwr,[],1);
        MNE.ori=[x;y;z]';
        %% removing swf and swf_pwr to save memory storage
        MNE = rmfield(MNE,{'swf','swf_pwr'}); MNE.avg = rmfield(MNE.avg,{'mom','filter','noisecov'});
        MNE.avg.pow = single(MNE.avg.pow);
        h.inv_soln(h.next_inv_soln).Type = 'MNE';
        h.inv_soln(h.next_inv_soln).soln = MNE;
        
         
        
        %% Plotting MNE
        %         img=MNE.P.img; ori=MNE.ori; null_thresh=max(img)*.25; %MNE.null_thresh*2;
        %
        %         min_max=[min(img) max(img)*.15]; %min_max = [0 5];
        %         sFaceAlpha=0; vol_types=1;
        %         figure(1006); clf; [peak_voxels,p_idx]=bl_plot_lcmv_peak_img_FT_new(img,ori,null_thresh,15,h.anatomy.leadfield.voxel_pos,jet(255),min_max,h.anatomy.vol.bnd(3),[],...
        %             h.cfg.study.bl_bmf.vw_angle,1,vol_types,h.anatomy.leadfield.pos,h.cfg.study.bl_bmf.inside_idx,h.cfg.study.bl_bmf.slice_orient,h.cfg.study.bl_bmf.sFaceAlpha);
        %         seed_idx = 1:3;  ln_wdth = 1; ln_wdth2 = 2;
        %         hold on; mrk_size=150; s1=scatter3(h.cfg.source.vx_locs(seed_idx,1),h.cfg.source.vx_locs(seed_idx,2),h.cfg.source.vx_locs(seed_idx,3),'k+','sizedata',mrk_size,'linewidth',ln_wdth); s2=scatter3(h.cfg.source.vx_locs(seed_idx,1),h.cfg.source.vx_locs(seed_idx,2),h.cfg.source.vx_locs(seed_idx,3),'ks','sizedata',mrk_size,'linewidth',ln_wdth2);
        %        title('FT MNE'); colorbar; caxis(min_max);
        %
        
        
end

    %% Listbox Name
    h.inv_soln(h.next_inv_soln).ListBox_name = sprintf('%s %s (%.f-%.f ms) %s',h.inv_soln(h.next_inv_soln).Type, h.menu_SPA_loc_flag.String{h.menu_SPA_loc_flag.Value} ,h.inv_soln(h.current_inv_soln).params.act_int*1000,h.inv_soln(h.current_inv_soln).headmodel_type);
    
    min_max = round([min(h.inv_soln(h.current_inv_soln).soln.P.img) max(h.inv_soln(h.current_inv_soln).soln.P.img)],3,'significant');
    if min_max(1)==min_max(2); min_max(2)=min_max(1)+1;
    elseif min_max(1)>min_max(2); min_max(2)=min_max(1)+1;
    end
    
    h.inv_soln(h.current_inv_soln).soln.plot_min_max = min_max;
    h.inv_soln(h.current_inv_soln).soln.plot_thresh = round(h.inv_soln(h.current_inv_soln).soln.plot_min_max(2)*.5,3,'significant'); %h.inv_soln(h.current_inv_soln).soln.null_thresh;
    h.edit_3D_min_max.String = sprintf('%.3f %.3f',h.inv_soln(h.current_inv_soln).soln.plot_min_max);
    
    % updating threshold slider
    h.slider_3D_image_thresh.Max = h.inv_soln(h.current_inv_soln).soln.plot_min_max(2);
    h.slider_3D_image_thresh.Min = h.inv_soln(h.current_inv_soln).soln.plot_min_max(1);
    h.slider_3D_image_thresh_text_max.String = num2str(h.slider_3D_image_thresh.Max);
    if h.slider_3D_image_thresh.Value>h.slider_3D_image_thresh.Max
        h.slider_3D_image_thresh.Value = h.slider_3D_image_thresh.Max;
    elseif h.slider_3D_image_thresh.Value < h.slider_3D_image_thresh.Min
        h.slider_3D_image_thresh.Value = h.slider_3D_image_thresh.Min;
    end
    
    bs_update_3D_listbox();
    bs_plot_inv_soln;
    fprintf('Inverse Modeling Completed for %s\n',inv_soln);

%% converting to single precision for reduce memory storage
h.inv_soln(h.next_inv_soln).soln.wts = single(h.inv_soln(h.next_inv_soln).soln.wts);
h.inv_soln(h.next_inv_soln).soln.ori = single(h.inv_soln(h.next_inv_soln).soln.ori);
h.inv_soln(h.next_inv_soln).soln.ori = single(h.inv_soln(h.next_inv_soln).soln.ori);
h.inv_soln(h.next_inv_soln).soln.P.img = single(h.inv_soln(h.next_inv_soln).soln.P.img);
% reducing redundancy to save storage space
h.inv_soln(h.next_inv_soln).leadfield = rmfield(h.inv_soln(h.next_inv_soln).leadfield,{'cfg','leadfield','H'});
h.inv_soln(h.next_inv_soln).leadfield = double2single(h.inv_soln(h.next_inv_soln).leadfield);


catch me
    errordlg('ERROR! Inverse Source Modeling Failed');
end
h.waitfor_panel.Visible='off'; h.waitfor_txt.String = sprintf('Default Message');
% close(hm);


