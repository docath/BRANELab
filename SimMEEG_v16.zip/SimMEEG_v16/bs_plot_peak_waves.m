function bs_plot_peak_waves(varargin)
global h
axes(h.axes_source_waves); cla; hold on;
ln_clr = lines(length(h.current_3D_peak_idx)); ln_clr(1:3,:) = h.src_clr;

bs = round( (h.sim_data.cfg.study.base_int-h.sim_data.cfg.study.lat_sim(1))*h.sim_data.cfg.study.srate); bs(bs==0)=1;
h.sim_data.cfg.study.base_samps = bs(1):bs(2);
avg_data = nan(size(h.sim_data.sig_final,1),size(h.sim_data.sig_final,2));

if ~isfield(h.sim_data.cfg.study,'bl_bmf')
    h.sim_data.cfg.study.bl_bmf=[];
    if ~isfield(h.sim_data.cfg.study.bl_bmf,'inside_idx')
        h.sim_data.cfg.study.bl_bmf.inside_idx = find(h.inv_soln(h.current_inv_soln).leadfield.inside==1);
    end
end



try
% if h.radio_3D_peak_locs.Value==1
% calculating source waveforms 'swf' for peaks in the 3D maps
switch h.inv_soln(h.current_inv_soln).Type
    case {'SPA','SIA','MIA','LCMV','sLORETA'}    % BRANE Lab beamformers
        h.current_peak_swf = [h.inv_soln(h.current_inv_soln).soln.wts(:,h.current_3D_peak_idx)'*squeeze(nanmean(h.sim_data.sens_final,3))']';
    case {'eLORETA'}    % Field Trips inverse solutions
        %         h.current_peak_swf = squeeze(rms(h.inv_soln(h.current_inv_soln).soln.swf(:,:,h.current_3D_peak_idx),2)); % taking RMS of waveforms across orientations
        swf=[];
        for ox = 1:size(h.inv_soln(h.current_inv_soln).soln.wts,3)
            swf(:,ox,:)=squeeze(nanmean(h.sim_data.sens_final,3))*squeeze(h.inv_soln(h.current_inv_soln).soln.wts(:,h.current_3D_peak_idx,ox));
        end
        h.current_peak_swf = squeeze(rms(swf,2)); % taking RMS of waveforms across orientations
%         xs = sign(swf); [q,w]= max(max(swf,[],1),[],2); w=squeeze(w);
%         for v=1:size(swf,3)
%                 h.current_peak_swf(:,v) = h.current_peak_swf(:,v) .* squeeze(xs(:,w(v),v));
%         end
        
    case {'MNE'}    % Field Trips inverse solutions
        %             h.current_peak_swf = [h.inv_soln(h.current_inv_soln).soln.wts(:,h.current_3D_peak_idx)'*squeeze(nanmean(h.sim_data.sens_final,3))']';
        switch h.inv_soln(h.current_inv_soln).headmodel_type
            case 'Whole Brain'
                h.current_peak_swf = h.inv_soln(h.current_inv_soln).soln.avg.pow(h.sim_data.cfg.study.bl_bmf.inside_idx(h.current_3D_peak_idx),:)';
            case 'Cortical Surface'
                h.current_peak_swf = h.inv_soln(h.current_inv_soln).soln.avg.pow(h.current_3D_peak_idx,:)';
        end
end


% baselining
h.current_peak_swf = bsxfun(@minus,h.current_peak_swf,nanmean(h.current_peak_swf(h.sim_data.cfg.study.base_samps,:)));
% Flip wave --> flipping wave if orientation is in oppposite quadrant (i.e., close to 180deg out of phase with true orientation);

try
    [v_idx]=find_nearest_voxel(h.current_3D_peak_voxels(:,1:3),h.cfg.source.vx_locs);
    for v=unique(v_idx)   % only flipping the first 3 that have been reordered
        true_ori = h.sim_data.cfg.source.vx_ori(v,:);
        peak_ori = nan(size(true_ori));
        peak_ori2 = h.inv_soln(h.current_inv_soln).soln.ori(h.current_3D_peak_idx(v),:);
        peak_ori(1:size(peak_ori2,1),1:size(peak_ori2,2)) = peak_ori2;
%         peak_ori = h.inv_soln(h.current_inv_soln).soln.ori(h.current_3D_peak_idx(v),:);
        if nansum(abs(true_ori-peak_ori)) > nansum(abs(true_ori+peak_ori)) % flip swf
            
            switch h.inv_soln(h.current_inv_soln).Type
                case {'SPA' 'SIA' 'MIA' 'LCMV' 'sLORETA'}     % scalar
                    h.current_peak_swf(:,v) = h.current_peak_swf(:,v)*-1;
                    h.inv_soln(h.current_inv_soln).soln.wts(:,h.current_3D_peak_idx(v)) = h.inv_soln(h.current_inv_soln).soln.wts(:,h.current_3D_peak_idx(v))*-1;
                    
                case {'eLORETA' 'MNE'}   % vector
            end
            % flip orientation
            h.inv_soln(h.current_inv_soln).soln.ori(h.current_3D_peak_idx(v),:) = h.inv_soln(h.current_inv_soln).soln.ori(h.current_3D_peak_idx(v),:)*-1;

            
            vx_pos = h.inv_soln(h.current_inv_soln).leadfield.voxel_pos(h.current_3D_peak_idx(v),:);
            clear ori_pos
            ori_pos(1,:) = h.map3D_peak_ori(v).XData-vx_pos(1);   % center ori at vox_pos then flip it
            ori_pos(2,:) = h.map3D_peak_ori(v).YData-vx_pos(2);
            ori_pos(3,:) = h.map3D_peak_ori(v).ZData-vx_pos(3);
            
            h.map3D_peak_ori(v).XData = vx_pos(1) + ori_pos(1,:)*-1;   % flipping orientation on image
            h.map3D_peak_ori(v).YData = vx_pos(2) + ori_pos(2,:)*-1;   % flipping orientation on image
            h.map3D_peak_ori(v).ZData = vx_pos(3) + ori_pos(3,:)*-1;   % flipping orientation on image
        end
    end
catch
    fprintf('ERROR in automatically flipping orientations for %s\n', h.inv_soln(h.current_inv_soln).Type)
end
%% normalizing z-transform relative to standard deviation of the baseline
mu_base = repmat(nanmean(h.current_peak_swf(h.sim_data.cfg.study.base_samps,:)),size(h.current_peak_swf,1),1);
sigma_base = repmat(nanstd(h.current_peak_swf(h.sim_data.cfg.study.base_samps,:)),size(h.current_peak_swf,1),1);

norm_swf = (h.current_peak_swf-mu_base) ./ sigma_base;    % Z-score
h.current_norm_peak_swf = norm_swf;  % peak waves are all z-score normalized now to baseline

h.norm_true_swf=[];
for v=1:3
    data = squeeze(h.sim_data.sig_final(:,v,:)); data = bsxfun(@minus,data,nanmean(data(h.sim_data.cfg.study.base_samps,:,:)))*str2num(h.edit_source_amp(v).String);
    avg_data(:,v) = squeeze(nanmean(data,2));
    mu = repmat(nanmean(avg_data(h.sim_data.cfg.study.base_samps,v)),size(avg_data,1),1);
    sigma = repmat(nanstd(avg_data(h.sim_data.cfg.study.base_samps,v)),size(avg_data,1),1);
    h.norm_true_swf(:,v) = avg_data(:,v); %(avg_data(:,v)-mu) ./ sigma;
    
    switch h.inv_soln(h.current_inv_soln).Type
        case {'SPA' 'SIA' 'MIA' 'LCMV' 'sLORETA'}     % scalar
        case {'eLORETA' 'MNE'}   % vector
            h.norm_true_swf(:,v) = abs(h.norm_true_swf(:,v));     % taking abs to match calculated swf
    end
    h.current_true_swf_plots(v) = plot(h.axes_source_waves,h.sim_data.cfg.study.lat_sim, h.norm_true_swf(:,v),'-','color',h.src_clr(v,:),'linewidth',1);
end


%% plotting normalized inv peaks waves
for v=1:size(h.current_peak_swf,2)
    h.current_inv_swf_plots(v) = plot(h.axes_source_waves,h.sim_data.cfg.study.lat_sim,h.current_norm_peak_swf(:,v),'color',ln_clr(v,:),'linewidth',2);
end
% else
% end

if h.radio_3D_true_locs.Value==1 && h.radio_3D_peak_locs.Value==0 && ~isempty(h.current_3D_peak_idx) % only true source waves
    legend(h.axes_source_waves,h.current_true_swf_plots,{'True S1' 'True S2' 'True S3'});
elseif h.radio_3D_true_locs.Value==0 && h.radio_3D_peak_locs.Value==1  && ~isempty(h.current_3D_peak_idx) % only peak waves
    legend(h.axes_source_waves,h.current_inv_swf_plots(1),{'Peak Waves'});
elseif h.radio_3D_true_locs.Value==1 && h.radio_3D_peak_locs.Value==1  && ~isempty(h.current_3D_peak_idx) % both
    legend(h.axes_source_waves,{'True S1' 'True S2' 'True S3' 'Peak Waves'});
else
    legend(h.axes_source_waves,{'True S1' 'True S2' 'True S3'});
end
h.axes_source_waves.Legend.Position = [0.12    0.2795    0.1535    0.1218];

xdata = cat(2,h.current_norm_peak_swf,h.norm_true_swf);
h.axes_source_waves.YLim = [-1.1*max(max(abs(xdata))) 1.1*max(max(abs(xdata))) ];

h.axes_source_waves.XLim = str2num(h.edit_plot_time_int.String);
h.axes_source_waves.XLabel.String = 'Time (sec)'; h.axes_source_waves.YLabel.String = 'Normalized Amplitude';
h.axes_source_waves.Visible = true;
h.axes_source_waves.Title.String = 'Peak Waves for Inverse Solution';



if ~isempty(h.current_peak_swf)
    bs_calc_fft;
end
bs_calc_errors_inv_soln;

catch me
    fprintf('ERROR: Source weights do no match number of sensors\nLikely using weights calculated using EEG but current sensors are MEG, or vice versa\n\n'); 
    h.current_peak_swf = [];
    h.axes_source_fft.clo;
    h.axes_source_waves.clo;
    h.axes_invSoln_errors_locs.clo;
    h.axes_invSoln_errors_ori.clo;
    h.axes_invSoln_errors_waves.clo;
end

