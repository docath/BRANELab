function listbox_peaks_found_Callback(varargin)
global h

sel_locs = h.inv_soln(h.current_inv_soln).leadfield.voxel_pos(h.current_3D_peak_idx(h.listbox_peaks_found.Value),:);
if isfield(h,'current_peak_selected')
    if isvalid(h.current_peak_selected)
        h.current_peak_selected.XData = sel_locs(1); h.current_peak_selected.YData = sel_locs(2); h.current_peak_selected.ZData = sel_locs(3); 
    else
        h.current_peak_selected = scatter3(h.axes_3D_images,sel_locs(1),sel_locs(2),sel_locs(3),'o','MarkerEdgeColor',[1 0 1],'SizeData',200,'linewidth',2);
    end
else
    h.current_peak_selected = scatter3(h.axes_3D_images,sel_locs(1),sel_locs(2),sel_locs(3),'o','MarkerEdgeColor',[1 0 1],'SizeData',200,'linewidth',2);
end



